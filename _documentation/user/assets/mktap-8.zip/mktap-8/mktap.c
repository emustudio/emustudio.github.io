/*
 *	Copyright (C) 2007, 2020-2021 Jan Bobrowski
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	version 2 as published by the Free Software Foundation.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>

#if !defined _WIN32 && !defined _DOS
#include <err.h>
#include <unistd.h>
#else
#include <fcntl.h>
#include <stdarg.h>
#ifdef __ia16__
#include <unistd.h>
#endif

void warnx(char *f, ...)
{
	va_list a; va_start(a, f);
	vfprintf(stderr, f, a); va_end(a);
	fprintf(stderr, "\n");
}

void errx(int s, char *f, ...)
{
	va_list a; va_start(a, f);
	vfprintf(stderr, f, a);
	va_end(a);
	fprintf(stderr, "\n");
	exit(s);
}

#endif

#include "mktap.h"

#pragma clang diagnostic ignored "-Wshift-op-parentheses"

struct buf data = {0,0};

static char RAND_USR_REM[] = "\0\0\0\0"
	"\xF9\xC0("
	 "0\16\0\0\x2B\0\0"
	"+\xBE"
	 "0\16\0\0\x53\x5C\0"
	"+0\16\0\0\0\1\0"
	"*\xBE"
	 "0\16\0\0\x54\x5C\0"
	")"
	":\xEA";

struct u16le { u8 l, h; };

struct header {
	u8 type;
	u8 name[10];
	struct u16le length, start, prog;
};

#define put16(D,V) ((D).l=(V),(D).h=(V)>>8)

static void read_into_data(FILE *f)
{
	for (;;) {
		int v;
		data.ptr = realloc(data.ptr, data.size + 1024);
		if (!data.ptr) errx(1, "Out of memory");
		v = fread(data.ptr + data.size, 1, 1024, f);
		if (v == 0) break;
		data.size += v;
	}
}

static void save(int x, u8 *d, int l)
{
	int n;

	putchar(l+2);
	putchar(l+2 >> 8);

	putchar(x);
	n = fwrite(d, 1, l, stdout);
	if (n < l) errx(1, "fwrite: %d < %d", n, l);

	for (n=0; n<l; n++)
		x ^= d[n];
	putchar(x);
}

static void usage(FILE *o)
{
	fprintf(o, "mktap [-rb] [-R file] [-t num] name [start] <input >output.tap\n"
		" -b       convert text file to Basic program\n"
		" -t num   file type (0:basic, 3:bytes)\n"
		" -r       headless (data block only)\n"
		" -rr      raw data (not a tape)\n"
		" -R file  put data in REM (if -b)\n"
		" -U       USR the code (if -R)\n"
	);
	exit(1);
}

int main(int argc, char *argv[])
{
	int raw = 0;
	int basic = 0;
	int type = -1;
	u16 start;
	int usrcode = 0;
	char *remdata=0;
	struct header h;

	for(;;) switch(getopt(argc, argv, "?hrt:bR:U")) {
	case EOF: goto endopt;
	case 'r': raw++; break;
	case 'b': basic = 1; break;
	case 't': type = atoi(optarg); break;
	case 'R': remdata = optarg; break;
	case 'U': usrcode = 1; break;
	case '?':
	case 'h':
		printf("mktap by Jan Bobrowski\n"
		 "version: "STR(VERSION)", compiled: "__DATE__"\n");
		usage(stdout);
	default:
		usage(stderr);
	}
endopt:

	if (optind == argc)
		usage(isatty(1) ? stdout : stderr);

	{
		char *name = argv[optind++];
		int l = strlen(name);
		if (l > sizeof h.name) l = sizeof h.name;
		memset(h.name, ' ', sizeof h.name);
		memcpy(h.name, name, l);
	}

	start = 0xffff;
	if (optind < argc) {
		start = atoi(argv[optind++]);
		if (optind < argc)
			warnx("Too many args: %s", argv[optind]);
	}

#ifdef _WIN32
	_setmode(_fileno(stdout), _O_BINARY);
#endif

	if (!basic) {
		if (start < 0)
			start = 0;
		read_into_data(in);
		if (type < 0)
			type = 3;
	} else {
		if (remdata) {
			FILE *f = fopen(remdata, "rb");
			int n, o;
			if (!f) errx(1,"can't open %s", remdata);
			o = data.size; // zero, I know
			n = usrcode ? sizeof RAND_USR_REM-1 : 5;
			data.ptr = realloc(data.ptr, data.size+=n);
			if (usrcode)
				memcpy(data.ptr+o, RAND_USR_REM, n);
			else
				memcpy(data.ptr+o, "\0\0\0\0\xEA", 5);
			read_into_data(f);
			fclose(f);
			data.ptr = realloc(data.ptr, data.size+=1);
			data.ptr[data.size-1] = 13;
			n = data.size - o - 4;
			data.ptr[o+2] = n;
			data.ptr[o+3] = n>>8;
		}
		read_basic();
		if (type<0) type=0;
	}

	if (!raw) {
		h.type = type;
		put16(h.length, data.size);
		put16(h.start, start);
		if(basic) put16(h.prog, basic ? data.size : 0);

		save(0, (u8 *)&h, sizeof h);
		save(0xFF, data.ptr, data.size);
	} else if(raw==1)
		save(type, data.ptr, data.size);
	else
		fwrite(data.ptr, 1, data.size, stdout);

	return 0;
}
