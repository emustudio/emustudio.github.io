#include <stdint.h>

#define elemof(T) (sizeof T/sizeof*T)
#define STR_(A) #A
#define STR(A) STR_(A)

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

struct buf {
	u8 *ptr;
	unsigned size;
};

#define in stdin

void read_basic();
