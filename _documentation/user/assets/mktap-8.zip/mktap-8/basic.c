/*
 *	Copyright (C) 2005-2007, 2010, 2020-2021 Jan Bobrowski
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	version 2 as published by the Free Software Foundation.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "mktap.h"

extern struct buf data;
static int lineb;

static void append(u8 v)
{
	if(!(data.size & 0777))
		data.ptr = realloc(data.ptr, data.size + 01000);
	data.ptr[data.size++] = v;
}

void start_line(int n)
{
	append(n>>8); append(n&0xFF);
	append(0); append(0);
	lineb = data.size;
}

static int checkkw();

void end_line()
{
	int n;
	checkkw();
	append(13);
	n = data.size - lineb;
	data.ptr[lineb-2] = n&0xFF;
	data.ptr[lineb-1] = n>>8;
	lineb = -1;
}

static char *stab[] = {
/*2*/	"PI\247FN\250AT\254LN\270IN\277OR\305<=\307>=\310<>\311TO\314IF\372",
/*3*/	"RND\245TAB\255VAL\260LEN\261SIN\262COS\263TAN\264ASN\265ACS\266"
	"ATN\267EXP\271INT\272SQR\273SGN\274ABS\275USR\300NOT\303BIN\304"
	"AND\306CAT\317INK\331OUT\337NEW\346DIM\351REM\352FOR\353LET\361"
	"RUN\367CLS\373",
/*4*/	"ATTR\253VAL$\256CODE\257PEEK\276STR$\301CHR$\302LINE\312THEN\313"
	"STEP\315MOVE\321BEEP\327OVER\336STOP\342READ\343DATA\344LOAD\357"
	"LIST\360NEXT\363POKE\364PLOT\366SAVE\370DRAW\374COPY\377" "GOTO\354"
	"PLAY\244",
/*5*/	"POINT\251ERASE\322MERGE\325PAPER\332FLASH\333LLIST\341GO TO\354"
	"INPUT\356PAUSE\362PRINT\365CLEAR\375" "OPEN#\323GOSUB\355",
/*6*/	"INKEY$\246DEF FN\316FORMAT\320OPEN #\323VERIFY\326CIRCLE\330BRIGHT\334"
	"LPRINT\340BORDER\347GO SUB\355RETURN\376" "CLOSE#\324",
/*7*/	"SCREEN$\252CLOSE #\324INVERSE\335RESTORE\345",
/*8*/	"CONTINUE\350" "SPECTRUM\243",
/*9*/	"RANDOMIZE\371",
};

#define DEF_FN 0316
#define BIN 0304

static int checkkw()
{
	int l;
	l = 9;
	for(;l>=2;l--) {
		unsigned char *s = data.ptr+data.size-l;
		char *p = stab[l-2];
		if(s[-1]>='A' && s[-1]<='Z')
			continue;
		do {
			if(memcmp(s,p,l) == 0) {
				int c = p[l]&0xFF;
				if(s[-1] == ' ') s--;
				*s++ = c;
				data.size = s-data.ptr;
				return c;
			}
			p += l+1;
		} while(*p);
	}
	return 0;
}

static void outE(double v)
{
	append(14);
	if((u16)v == v) {
		u16 s = v;
		append(0); append(0);
		append(s&0xFF); append(s>>8);
		append(0);
	} else {
		int e;
		u32 m = frexp(v, &e) * 65536 * 65536;
		append(e+128);
		append(m>>24 & 0x7F);
		append(m>>16);
		append(m>>8);
		append(m);
	}
}

static void cvtnum(int c, int bin)
{
	double v = 0;

	if(bin) {
		while(c>='0' && c<='1' && v<32768) {
			append(c);
			v = 2*v + (c&1);
			c = getc(in);
		}
		goto out;
	}

	if(c == '.')
		goto real;
	for(;;) {
		append(c);
		v = 10*v + c-'0';
		c = getc(in);
		if(c<'0' || c>'9')
			break;
	}
	if(c == '.') {
		double m;
real:
		m = 1;
		for(;;) {
			append(c);
			c = getc(in);
			if(c<'0' || c>'9')
				break;
			m /= 10;
			v += m * (c - '0');
		}
	}

out:
	ungetc(c, in);
	outE(v);
}

static int linenr;
static void def_fn(); // special case

#define GRAVE_G 1  // ` introduces UDG A-U in strings, `c for copy, `# for pound

static int cvtline()
{
	int c,g;

	for(;;) {
		c = getc(in);
		if(c < 0) return 0;
		if(c > ' ') {
			if(c != '#') {
				ungetc(c, in);
				break;
			}
			/* # comment */
			do {
				c = getc(in);
				if(c < 0) return 0;
			} while(c != '\n');
			return 1;
		}
	}

	if(fscanf(in, "%d", &linenr) <= 0)
		linenr++;
	start_line(linenr);

	c = getc(in);
	if(c!='>') ungetc(c, in); // skip line marker

	for(;;) {
		c = getc(in);
		if(c<0) goto fail;
		if(c=='"') {
			checkkw();
			if(GRAVE_G) g=0;
			do {
				append(c);
get_next:
				c = getc(in);
				if(c==10 || c<0) {
					ungetc(c,in);
					goto fail;
				}
				if(!GRAVE_G)
					continue;
				if(c=='`') {
					g ^= 0x4F;
					goto get_next;
				}
				if(!g) continue;
				if(c>='A' && c<='U')
					c += g;
				else if(c=='c')
					c = 127; // copy
				else if(c=='#' || c=='`')
					c = 96; // pound
			} while(c!='"');
		}
		if(c>='0' && c<='9' || c=='.') {
			checkkw();
			cvtnum(c, 0);
			continue;
		}
		if(c<'A' && c!='$' || c>'Z') {
			int kw = checkkw();
			switch(kw) {
			case DEF_FN:
				if(c!=' ')
					ungetc(c,in);
				def_fn();
				continue;
			case BIN:
				if(c==' ')
					c = getc(in);
				cvtnum(c, BIN);
				continue;
			default:
				if(c==' ')
					continue;
			case 0:
				break;
			}
		}
		if(c==10) break;
		append(c);
	}
	end_line();
	return 1;
fail:
	end_line();
	return 0;
}

static void def_fn()
{
	const char *term = "\n:)";
	int c;
	do {
		c = getc(in);
		if(c<0 || strchr(term,c))
			goto ret;
		append(c);
	} while(c!='(');
	for(;;) {
		c = getc(in);
		if(c<0 || strchr(term,c))
			goto ret;
		append(c);
		if((c<'a' || c>'z') && (c<'A' || c>'Z'))
			continue;
		c = getc(in);
		if(c=='$')
			append(c);
		else {
			if(c<0) return;
			ungetc(c,in);
		}
		outE(0);
	}
ret:
	ungetc(c,in);
}

void read_basic()
{
	data.ptr = realloc(data.ptr, data.size+01000);
	while(cvtline());
}
